package com.cg.bank.entity;

public class Account {

	int accountNumber;
	int accountType;
	String branch;
	String IFSC;
	double balance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Account(int accountNumber, int accountType2, String branch,
			String iFSC, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType2;
		this.branch = branch;
		IFSC = iFSC;
		this.balance = balance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getAccountType() {
		return accountType;
	}
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIFSC() {
		return IFSC;
	}
	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + "\n accountType="
				+ accountType + "\n branch=" + branch + "\n IFSC=" + IFSC
				+ "\n balance=" + balance ;
	}
	
	
}
