package com.cg.bank.ui;

import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.service.CustomerService;
import com.cg.bank.service.CustomerServiceImpl;

public class RunMain {
	static Scanner sc=null;
	static CustomerService cs=null;
	public static void main(String[] args) throws CustomerException {
		sc=new Scanner(System.in);
		cs=new CustomerServiceImpl();
		while(true)
		{
		System.out.println("Welcome to ASN BANK");
		System.out.println("Choose your Transaction: ");
		System.out.println("1.Create a Account\n2.ShowBalance");
		System.out.println("3.Deposit\n4.Withdraw");
		System.out.println("5.FundTransfer\n6.PrintTransactions");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			createAccount();
			break;
		case 2:
			showBalance();
			break;
		case 3:
			deposit();
			break;
		case 4:
			withdraw();
			break;
		case 5:
			fundTransfer();
			break;
		case 6:
			printTransaction();
			break;
				
		}
	}
	}
	public static void createAccount() throws CustomerException
	{
		String branch="Bangalore";
		String IFSCCode="IFSC1234";
		System.out.println("Enter CustomerName: ");
		String name=sc.next();
		try{
		if(cs.validateCustomerName(name))
		{
		System.out.println("Enter Customer MobileNumber: ");
		String mobileno=sc.next();
		try{
		if(cs.validateCustomerNo(mobileno))
		{
		System.out.println("Enter Customer address: ");
		String address=sc.next();
		System.out.println("Choose Account type\n 1.current\n 2.savings:");
		int accountType=sc.nextInt();
		switch(accountType){
		case 1:
			System.out.println("current");
			break;
		case 2:
			System.out.println("savings");
		break;
		}
		System.out.println("Enter the Intial amount to open the account: ");
		double amount=sc.nextDouble();
		 int accountno = (int) (Math.random()*10000);
		 Customer c=new Customer(accountno, name, mobileno, address);
		 Account a=new Account(accountno, accountType, branch, IFSCCode,amount);
		int acc= cs.createAccount(c, a);
		System.out.println("Your Account Successfully Created");
		System.out.println("Your account noumber is: "+acc);
		}	
		}
		catch(Exception e)
		{
			throw new CustomerException("Enter valid mobile number");
		}
		}
		}
		catch(Exception e)
		{

			throw new CustomerException("Enter valid name");
		}
	}
	public static void showBalance()
	{
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		double ac=cs.showBalance(accountno);
		if(ac==0)
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account number");
			
		}
		else
		{
			System.out.println("Entered Account no: "+accountno+" Current Balance is $"+ac);		
		}	break;
		}
	}
	public static void deposit()
	{
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Deposit");
		double amount=sc.nextDouble();
		cs.deposit(amount, accountno);
		System.out.println("Successfully Deposited....");
		System.out.println("your balance is:"+" "+amount);
		}
		else
		{
			System.out.println("Entered account number is not Existed..Enter valid Account no.");
		}
	break;
		}
	}
	public static void withdraw()
	{
		while(true)
		{
		System.out.println("Enter your accountnumber ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Withdraw");
		double amount=sc.nextDouble();
		double d=cs.withdraw(amount, accountno);
		if(d==0)
		{
			System.out.println("Insufficient funds need to Deposit: ");
			
		}
		else
		{
			System.out.println("Successfully Withdraw....");
			System.out.println("your balance is:"+" "+amount);

		}
	}
		else
		{
			System.out.println("Entered account number is not Existed..Enter valid Account no.");
		}break;
	}
		
	}
	public static void fundTransfer()
	{
		while(true)
		{
		System.out.println("Enter your accountnumber ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
			System.out.println("Enter accountnumber to transfer the money ");
			int accountno2=sc.nextInt();
			while(true)
			{
			if(cs.showBalance(accountno2)!=0)
			{
				System.out.println("Enter Money to Transfer");
				double amount=sc.nextDouble();
				if(cs.fundTransfer(amount, accountno, accountno2))
				{
					System.out.println("Amount successfully Transferred.....");
					System.out.println("your balance is:"+" "+amount);
				}
				else{
					System.out.println("Insufficient funds need to deposit");
					
				}
				
			}
			else
			{
				System.out.println("Entered account number is not Existed..Enter valid Account number");
			}break;
			}
			
		}
		else
		{
			System.out.println("Entered account number is not Existed..Enter valid Account number");
		}break;
		}
	}
	public static void printTransaction()
	{
		System.out.println("Enter Account Number");
		int accno=sc.nextInt();
		System.out.println(cs.printTransaction(accno));
	}

}
