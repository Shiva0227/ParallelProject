package com.cg.bank.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class TestCases {

	static CustomerDAO cusdao=null; 
	@BeforeClass
		public static void setUp()
		{
			cusdao=new CustomerDAOImpl();
		} 
	@Test
	public void createAccountTest() {
		Assert.assertEquals(1111, cusdao.createAccount(new Customer(1111, "shiva", "8978457856", "Bangalore"), new Account(1111,1,"Bangalore","IFSC1234",50000)));
	}


}
