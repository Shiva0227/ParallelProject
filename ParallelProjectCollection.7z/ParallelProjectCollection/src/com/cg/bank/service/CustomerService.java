package com.cg.bank.service;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface CustomerService {
	public int createAccount(Customer c,Account a);
	public double showBalance(int accountno);
	public double deposit(double amount,int accountNo);
	public double withdraw(double amount,int accountNo);
	public boolean fundTransfer(double amount,int accountno,int accountno2);
	public Account printTransaction(int accountno);
	public boolean validateCustomerName(String name);
	public boolean validateCustomerNo(String mobileNo);
	

}
