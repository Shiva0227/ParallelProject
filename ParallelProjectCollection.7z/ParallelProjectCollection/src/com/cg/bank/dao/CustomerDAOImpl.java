package com.cg.bank.dao;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.Util;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public int createAccount(Customer c, Account a) {
		
		return Util.createAccount(c, a);
	}

	@Override
	public double showBalance(int accountNo) {
		
		return Util.showBalance(accountNo);
	}

	@Override
	public double deposit(double amount, int accountNo) {
		
		return Util.deposit(amount, accountNo);
	}

	@Override
	public double withdraw(double amount, int accounNo) {
		
		return Util.withdraw(amount, accounNo);
	}

	@Override
	public boolean fundTransfer(double amount,int accountNo1,
			int accountNo2) {
				return Util.fundTransfer(amount, accountNo1, accountNo2);
		
	}

	@Override
	public Account printTransaction(int accountno) {
		return Util.printTransaction(accountno);
		
	}

}
