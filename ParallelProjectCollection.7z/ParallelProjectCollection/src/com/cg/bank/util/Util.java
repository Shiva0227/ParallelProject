package com.cg.bank.util;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class Util {
	private static HashMap<Integer, Customer> hmc=new HashMap<>();
	private static HashMap<Integer, Account> hma=new HashMap<>();
	static{
		hmc.put(1111, new Customer(1111, "shiva", "8978457856", "Bangalore"));
		hmc.put(2222, new Customer(2222, "sai", "9748786532", "Chennai"));
		hmc.put(3333, new Customer(3333, "Nikhil", "7895683525", "Delhi"));
		hmc.put(4444, new Customer(4444, "shiva", "1257845698", "Mumbai"));
		hma.put(1111, new Account(1111,1,"Bangalore","IFSC1234",50000));
		hma.put(2222, new Account(2222,1,"Bangalore","IFSC1234",60000));
		hma.put(3333, new Account(3333,1,"Bangalore","IFSC1234",75000));
		hma.put(4444, new Account(4444,1,"Bangalore","IFSC1234",100000));
		
	}
	public static int createAccount(Customer c,Account a)
	{
		hmc.put(c.getAccountNo(), c);
		hma.put(a.getAccountNumber(), a);
		return a.getAccountNumber();
		
	}
    public static double showBalance(int accountNo)
    {
    	
    	if(hma.containsKey(accountNo))
    	{
    		Account ac=hma.get(accountNo);
    	   return ac.getBalance();
    	}
    	else
    	{
    		return 0;
    	}
    }
    public static double deposit(double amount,int accountno)
    {
    	double acc2=0;
    		Account ac=hma.get(accountno);
    		double acc=ac.getBalance();
    		acc2=amount+acc;
    		ac.setBalance(acc2);
    		hma.put(accountno, ac);
    		return acc2;
    	
    }
    public static double withdraw(double amount,int accounNo)
    {
    	double acc2=0;
    	Account ac=hma.get(accounNo);
    	double acc=ac.getBalance();
    		if(amount<=(acc-500))
    	{
    		acc2=acc-amount;
    		ac.setBalance(acc2);
    		hma.put(accounNo, ac);
    		return acc2;
    }
    		else
    		{
    		return 0;	
    		}
    		
    	}
    public static boolean fundTransfer(double amount,Integer accountno,Integer accountno1)
    {
    	double acc2=0;
    	double acc4=0;
    	Account ac=hma.get(accountno);
    	Account a=hma.get(accountno1);
    	double acc=ac.getBalance();
    	double acc3=ac.getBalance();
    		if(amount<=(acc-500))
    	{
    		acc2=acc-amount;
    		ac.setBalance(acc2);
    		hma.put(accountno, ac);
    	    acc4=acc3+amount;
    	    a.setBalance(acc4);
    	    hma.put(accountno1, a);
    		return true;
    }
    		else
		return false;
    	
    }
    	public static Account printTransaction(int accountno)
    	{
			return hma.get(accountno);
    		
    	}
    	
}
